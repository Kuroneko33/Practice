﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLib.DataController;
using DataLib.Network;

namespace Client.DataController
{
    public class DataControllerHttp : IDataController
    {
        public object GetSomething()
        {
            var jsonData = "params";
            return HttpRestClient.Get("serverPath" + "request", jsonData);
        }
    }
}
