﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Client
{
    public static class Config
    {
        public static ControllerType ControllerType = ControllerType.Sql;
    }


    public enum ControllerType
    {
        Sql,
        Http
    }
}
