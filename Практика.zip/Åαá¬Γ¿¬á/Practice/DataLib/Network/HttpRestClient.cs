﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLib.Network
{
    public class HttpRestClient
    {
        public static object Get(string serverPath, string data = "") 
        {
            return new object();
        }
        public static object Post(string serverPath, string data = "") 
        {
            return new object();
        }
    }
}
