﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLib.Network
{
    public class JsonConverter
    {
        public static string ToJson(object obj) => obj.ToString();
    }
}
