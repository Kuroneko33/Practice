﻿using DataLib.DataController;
using DataLib.Network;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Server
{
    public class WebHandl
    {
        private DataControllerSql DataController = new DataControllerSql();
        public void Receiver(string request)
        {
            if(request == "GetSomething")
                GetSomething();
        }

        public void GetSomething()
        {
            var dataObject = DataController.GetSomething();
            var jsonData = JsonConverter.ToJson(dataObject);
            HttpRestClient.Post("clientPath", jsonData);
        }
    }
}
