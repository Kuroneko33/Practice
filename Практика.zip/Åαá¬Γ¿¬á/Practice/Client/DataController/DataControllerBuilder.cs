﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataLib.DataController;

namespace Client.DataController
{
    public class DataControllerBuilder
    {
        public IDataController DataController
        {
            get
            {
                if (Config.ControllerType == ControllerType.Sql)
                    return new DataControllerSql();
                else
                    return new DataControllerHttp();
            }
        }
    }
}
