﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLib.DataController
{
    public class DataControllerSql : IDataController
    {
        public object GetSomething()
        {
            return "SELECT ...";
        }
    }
}
